<?php use Roots\Sage\Titles; ?>

<div class="page-header">
  <h2><?= Titles\the_field('Second Heading'); ?></h2>
</div>
