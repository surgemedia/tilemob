<?php use Roots\Sage\Titles; ?>

<div class="page-header">
  <h2><?php the_field('second_heading'); ?></h2>
</div>
