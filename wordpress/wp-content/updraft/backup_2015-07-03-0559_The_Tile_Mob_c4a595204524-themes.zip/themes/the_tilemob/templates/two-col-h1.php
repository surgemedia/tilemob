<?php use Roots\Sage\Titles; ?>

<div class="page-header">
  <h1><?php the_field('first_heading'); ?></h1>
</div>
