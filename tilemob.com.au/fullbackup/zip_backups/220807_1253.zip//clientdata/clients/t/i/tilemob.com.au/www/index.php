<html>
<head>
<title>Tiles, Stone, Mosaics, Slate, Terracotta - The Tile Mob</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('images/Home-over.gif','images/About-us-over.gif','images/New-in-store-over.gif','images/E3-Performance-over.gif','images/Conditions-of-sale-over.gif','images/Photo-gallery-over.gif','images/Contact-map-over.gif','images/btn_home_tiles_1.gif','images/btn_home_stone_1.gif','images/btn_home_mosaics_1.gif','images/btn_home_slate_1.gif','images/btn_home_terracotta_1.gif')">
<!-- ImageReady Slices (Template-6.psd) -->
<table width="800" height="659" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
	<tr>
	  <td width="800" height="204" colspan="9"><div align="center"><img src="images/The-Tile-Mob.gif" alt="The Tile Mob" width="313" height="131" border="0"><br>
	    <table width="313" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td><a href="tm_catalogue/index.php?open=gallery/tiles/wall/bathrooms/page1/index.php?page=1" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('tiles','','images/btn_home_tiles_1.gif',1)"><img src="images/btn_home_tiles_0.gif" alt="tiles" name="tiles" width="47" height="21" border="0"></a></td>
            <td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('stone','','images/btn_home_stone_1.gif',1)"><img src="images/btn_home_stone_0.gif" alt="stone" name="stone" width="57" height="21" border="0"></a></td>
            <td><a href="tm_catalogue/index.php?open=gallery/mosaics/page1/index.php?page=1" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('mosaic','','images/btn_home_mosaics_1.gif',1)"><img src="images/btn_home_mosaics_0.gif" alt="mosaics" name="mosaic" width="75" height="21" border="0"></a></td>
            <td><a href="tm_catalogue/index.php?open=gallery/slate/page1/index.php?page=1" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('slate','','images/btn_home_slate_1.gif',1)"><img src="images/btn_home_slate_0.gif" alt="slate" name="slate" width="52" height="21" border="0"></a></td>
            <td><a href="tm_catalogue/index.php?open=gallery/terracotta/page1/index.php?page=1" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('terracotta','','images/btn_home_terracotta_1.gif',1)"><img src="images/btn_home_terracotta_0.gif" alt="terracotta" name="terracotta" width="82" height="21" border="0"></a></td>
          </tr>
        </table>
	  </div></td>
	</tr>
	<tr>
		<td width="314" height="401" colspan="4" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="spacer"><img src="images/brisbane-premium-tiles.gif" alt="Welcome to the Tile Mob, Brisbane's Premium tile retailer" width="254" height="41"></td>
          </tr>
          <tr>
            <td class="the-tile-mob"><br>
            Whatever is happening in the world of tiles, whatever the innovation, 
            The Tile Mob will know about it.&nbsp; We source from the best manufacturers 
            around the world to offer you Brisbane&rsquo;s widest selection of 
            premium floor and wall tiles.&nbsp; <br>
            <br>
            Backed by proven systems, our experienced  team of tile stylists is ready to work with you to create compelling living or commercial spaces. <br>
            <br>            
            &nbsp;If you&rsquo;re after a  guaranteed quality outcome for your next tiling project, visit the team at The  Tile Mob today.</td>
          </tr>
          <tr>
            <td class="the-tile-mob2"><br>
                <img src="images/bullet-arrow.gif" alt="Bullet Arrow" width="12" height="12" align="absmiddle">Check out the new <a href="tm_catalogue/"><strong>Catalogue Browser </strong></a></td>
          </tr>
        </table></td>
		<td colspan="2">
			<img src="images/Premium-Floor-Tiles.jpg" width="118" height="401" alt="Premium Floor Tiles"></td>
		<td colspan="3"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="368" height="401" title="The Tile Mob">
          <param name="movie" value="flash/thetilemob.swf">
          <param name="quality" value="high">
          <embed src="flash/thetilemob.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="368" height="401"></embed>
	    </object></td>
	</tr>
	<tr>
		<td colspan="9">
			<img src="images/Tile-Mob.gif" width="800" height="5" alt="Tile-Mob"></td>
	</tr>
	<tr>
		<td><a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Home','','images/Home-over.gif',1)"><img src="images/Home.gif" name="Home" width="81" height="28" border="0"></a></td>
		<td>
			<a href="About-us.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('About Us','','images/About-us-over.gif',1)"><img src="images/About-us.gif" name="About Us" width="95" height="28" border="0"></a><a href="About-us.html"></a></td>
		<td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('New in Store','','images/New-in-store-over.gif',1)"><img src="images/New-in-store.gif" name="New in Store" width="121" height="28" border="0"></a></td>
		<td colspan="2"><a href="e3-performance-system.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('E3 Performance','','images/E3-Performance-over.gif',1)"><img src="images/E3-Performance.gif" name="E3 Performance" width="129" height="28" border="0"></a></td>
		<td colspan="2"><a href="Conditions-of-Sale.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Conditions of Sale','','images/Conditions-of-sale-over.gif',1)"><img src="images/Conditions-of-sale.gif" name="Conditions of Sale" width="143" height="28" border="0"></a></td>
		<td><a href="photo-gallery.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Photo Gallery','','images/Photo-gallery-over.gif',1)"><img src="images/Photo-gallery.gif" name="Photo Gallery" width="115" height="28" border="0"></a></td>
		<td><a href="contact-map.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Contact-Map','','images/Contact-map-over.gif',1)"><img src="images/Contact-map.gif" name="Contact-Map" width="116" height="28" border="0"></a></td>
	</tr>
	<tr>
		<td colspan="9">
			<img src="images/Tile-Mob-12.gif" width="800" height="5" alt="Tile-Mob"></td>
	</tr>
	<tr>
		<td width="800" height="15" colspan="9">&nbsp;</td>
	</tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="81" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="95" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="121" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="17" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="112" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="6" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="137" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="115" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="116" height="1" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>