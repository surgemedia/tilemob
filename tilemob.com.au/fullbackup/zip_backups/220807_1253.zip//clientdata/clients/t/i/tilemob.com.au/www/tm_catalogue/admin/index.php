<?php
header( 'Location: ../product_update.html' ) ;
?>