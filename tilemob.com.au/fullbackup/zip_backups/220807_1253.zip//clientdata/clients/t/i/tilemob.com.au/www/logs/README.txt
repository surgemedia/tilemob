To obtain your raw access logs, please FTP to logs.netregistry.net
using the same username and password as this log on.

Regards,
Support @ NetRegistry
